﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class CategoryController : Controller
    {
        ProjectContext _context = new ProjectContext();
        public IActionResult Index()
        {
            var _Categories = _context.Categories;
            return View(_Categories);
        }
        [HttpGet]
        public IActionResult ViewDetails(int id)
        {
            var _Category = _context.Categories.Find(id);
            if (_Category != null)
            {
                return View(_Category);
            }
            return View(_Category);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Category category)
        {
            _context.Categories.Add(category);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var oldCategory = _context.Categories.Find(id);
            if (oldCategory == null)
            {
                return RedirectToAction("Index");
            }
            return View(oldCategory);
        }
        [HttpPost]
        public IActionResult Edit(Category category)
        {
            var oldCategory = _context.Categories.FirstOrDefault(cgt => cgt.CategoryId == cgt.CategoryId);
            if (oldCategory == null)
            {
                return RedirectToAction("Index");
            }
            oldCategory.Name = category.Name;
            oldCategory.Description = category.Description;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            var CgtToDelete = _context.Categories.FirstOrDefault(cgt => cgt.CategoryId == cgt.CategoryId);
            if (CgtToDelete == null)
            {
                return RedirectToAction("Index");
            }
            _context.Categories.Remove(CgtToDelete);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
