﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.Controllers
{
    public class ProductController : Controller
    {
        ProjectContext _context = new ProjectContext();
        [HttpGet]
        public IActionResult Index()
        {
            var _Product = _context.Products.Include(Pro => Pro.Category);
            return View(_Product);
        }
        [HttpGet]
        public IActionResult ViewDetails(int id)
        {
            var _Product = _context.Products.Include(p => p.Category).FirstOrDefault(pr => pr.ProductId == id);
            if (_Product == null)
            {
                return RedirectToAction("Index");
            }
            return View(_Product);
        }
        /*---------------------------------------------------------*/
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag._Catogories= new SelectList(_context.Categories, "CategoryId", "Name");
            return View();
        }
        /*---------------------------------------------------------*/
        [HttpPost]
        public IActionResult Create(Product product)
        {
            ModelState.Remove("Category");
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "All Fields Required");
                ViewBag._Categories = new SelectList(_context.Categories, "Id", "Name");
                return View();
            }
            _context.Products.Add(product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        /*---------------------------------------------------------*/
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var _product = _context.Products.Include(e => e.Category).FirstOrDefault(emp => emp.ProductId == id);
            if (_product == null)
            {
                return RedirectToAction("Index");
            }
            ViewBag._Catogories = new SelectList(_context.Categories, "CategoryId", "Name");
            return View(_product);
        }
        /*---------------------------------------------------------*/
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            ModelState.Remove("Category");
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "All Fields Required");
                ViewBag._Catogories = new SelectList(_context.Categories, "CategoryId", "Name");
                return View();
            }
            _context.Products.Update(product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        /*---------------------------------------------------------*/
        public IActionResult Delete(int id)
        {
            var _Product = _context.Products.Find(id);
            if (_Product == null)
            {
                return RedirectToAction("Index");
            }
            _context.Products.Remove(_Product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
