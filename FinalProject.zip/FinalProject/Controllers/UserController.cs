﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class UserController : Controller
    {
        ProjectContext _context = new ProjectContext();
        [HttpGet]
        public IActionResult Index()
        {
            var _Users = _context.Users;
            
            return View(_Users);            // => View Model
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Login");
            }
            return View(user);
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users.SingleOrDefault(u => u.Email == email && u.Password == password);
            if (user != null)
            {
                // Set session or authentication here
                return RedirectToAction("Index","Product");
            }
            ModelState.AddModelError("", "Invalid login attempt.");
            return View();
        }
    }
}
