﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalProject.Models
{
    public class User
    {
        public int UserId { get; set; }
        [StringLength(15, MinimumLength = 2, ErrorMessage ="Firstname must be between 2 and 15 characters!")]
        [Required(ErrorMessage = "Firstname is required")]
        [DisplayName("Firstname")]
        public string FirstName { get; set; }
        [StringLength(15, MinimumLength = 2, ErrorMessage = "Lastname must be between 2 and 15 characters!")]
        [Required(ErrorMessage = "Lastname is required")]
        [DisplayName("Lastname")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email is Required.")]
        [EmailAddress]
        [DisplayName("User's Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password is required.")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long.")]
        public string Password { get; set; }

    }
}
