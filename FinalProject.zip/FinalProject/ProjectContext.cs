﻿using FinalProject.Models;
using Microsoft.EntityFrameworkCore;
namespace FinalProject
{
    public class ProjectContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=FinalProject;Trusted_Connection=True;Encrypt=false");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            var _Users = new List<User>
            {
                new User { UserId = 1, FirstName = "Salah", LastName = "Ayman", Email="salahayman2727@gmail.com", Password="Password1234" },
                new User { UserId = 2, FirstName = "Ahmed", LastName = "Mahmoud", Email="ahmed17sat@gmail.com", Password="Password1234" },
            };

            var _Categories = new List<Category>
            {
            new Category { CategoryId = 1, Name = "Electronics", Description = "Devices and gadgets" },
            new Category { CategoryId = 2, Name = "Clothing", Description = "Apparel and accessories" },
            new Category { CategoryId = 3, Name = "Books", Description = "Books and literature" },
            new Category { CategoryId = 4, Name = "Furniture", Description = "Home and office furniture" }
            };
            var _Products = new List<Product>
            {
                new Product { ProductId = 1, Title = "Smartphone", Price = 699.99m, Description = "Latest model smartphone", Quantity = 50, ImagePath = "/images/smartphone.jpg", CategoryId = 1 },
                new Product { ProductId = 2, Title = "Laptop", Price = 999.99m, Description = "High-performance laptop", Quantity = 30, ImagePath = "/images/laptop.jpg", CategoryId = 1 },
                new Product { ProductId = 3, Title = "Headphones", Price = 199.99m, Description = "Noise-cancelling headphones", Quantity = 100, ImagePath = "/images/headphones.jpg", CategoryId = 1 },
                new Product { ProductId = 4, Title = "T-Shirt", Price = 19.99m, Description = "100% cotton T-shirt", Quantity = 200, ImagePath = "/images/tshirt.jpg", CategoryId = 2 },
                new Product { ProductId = 5, Title = "Jeans", Price = 49.99m, Description = "Slim fit jeans", Quantity = 150, ImagePath = "/images/jeans.jpg", CategoryId = 2 },
                new Product { ProductId = 6, Title = "Novel", Price = 14.99m, Description = "Bestselling fiction novel", Quantity = 500, ImagePath = "/images/novel.jpg", CategoryId = 3 },
                new Product { ProductId = 7, Title = "Chair", Price = 89.99m, Description = "Ergonomic office chair", Quantity = 75, ImagePath = "/images/chair.jpg", CategoryId = 4 },
                new Product { ProductId = 8, Title = "Table", Price = 129.99m, Description = "Wooden dining table", Quantity = 40, ImagePath = "/images/table.jpg", CategoryId = 4 },
                new Product { ProductId = 9, Title = "Jacket", Price = 89.99m, Description = "Waterproof jacket", Quantity = 80, ImagePath = "/images/jacket.jpg", CategoryId = 2 },
                new Product { ProductId = 10, Title = "Bookshelf", Price = 59.99m, Description = "Wooden bookshelf", Quantity = 60, ImagePath = "/images/bookshelf.jpg", CategoryId = 4 }
            };
            
            modelBuilder.Entity<User>().HasData(_Users);
            modelBuilder.Entity<Category>().HasData(_Categories);
            modelBuilder.Entity<Product>().HasData(_Products);

         
        }
        
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
    }
}
